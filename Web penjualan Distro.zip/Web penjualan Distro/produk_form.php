<?php
$userName=$_POST['name'];
$pass=$_POST['pass'];
include"konektor.php";
	$sql = "select * from karyawan where NIK='$userName'";
	$hsl = mysqli_query($akses,$sql);
	$jumlah = mysqli_num_rows($hsl);
		if($jumlah<1){
			echo "MASUKAN UserName dan PASSWORD dengan BENAR!!!";
			echo "</br><input type='button' value='KEMBALI' onClick='self.history.back()'>";
			exit;
		}
?>
<?php
include"atas.php";
?>
<form action="produk_simpan.php" method="post" enctype="multipart/form-data">
<h1>PENGINPUTAN BARANG</h1>
	<table>
		<tr>
			<td>KODE</td>
			<td>:</td>
			<td><input type="text" name="kode"></td>
		</tr>
		<tr>
			<td>MERK</td>
			<td>:</td>
			<td><input type="text" name="merk"></td>
		</tr>
		<tr>
			<td>JENIS</td>
			<td>:</td>
			<td>
				<select name="jenis">
					<option value="">pilihan</option>
					<option value="kaos">KAOS</option>
					<option value="kemeja">KEMEJA</option>
					<option value="jersey">JERSEY</option>
					<option value="sweater">SWEATER</option>
				</select>
			</td>
		</tr>
		<tr>
			<td>SIZE
			<td>:</td>
			<td>
				<select name="size">
					<option value="">pilihan</option>
					<option value="S">S</option>
					<option value="M">M</option>
					<option value="L">L</option>
					<option value="XL">XL</option>
					<option value="XXL">XXL</option>
				</select>
			</td>
		</tr>
		<tr>
			<td>HARGA</td> 
			<td>:</td>
			<td><input type="text" name="harga"></td>
		</tr>
		<tr>
			<td>STOK</td> 
			<td>:</td>
			<td><input type="text" name="stok"></td>
		</tr>
		<tr>
			<td>GAMBAR</td> 
			<td>:</td>
			<td><input type="file" name="gambar"></td>
		</tr>
		<tr>
		<td colspan="2" align="center">
		<input type="submit" value="SIMPAN" name="simpan"/>
		<input type="reset" value="BATAL"/>
		</td>
		</tr>
	</table>
</form>
</br><a href="dataKonsumen.php">DATA KONSUMEN</a>&nbsp;&nbsp;<a href="produk_tampilKaryawan.php">DATA PRODUK</a>&nbsp;&nbsp;
<a href="dataTransaksi.php">STATUS TRANSAKSI</a>
<?php
include"bawah.php";
?>
