<?php
$noTransaksi= $_GET['noTransaksi'];
$date=date("Y-m-d");
	include"konektor.php";
	$sql 	= "update transaksi 
				set tglPengiriman='$date'
				where noTransaksi=$noTransaksi";
	$hasil	= mysqli_query($akses, $sql);
	header ('location:dataTransaksi.php');
?>