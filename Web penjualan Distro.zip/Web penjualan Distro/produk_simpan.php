<?php
include"atas.php";
	$kode	= $_POST ['kode'];
	$merk	= $_POST ['merk'];
	$jenis	= $_POST ['jenis'];
	$ukuran	= $_POST ['size'];
	$harga	= $_POST ['harga'];
	$stok	= $_POST ['stok'];
	
	$foto	= $_FILES['gambar']['name'];
	$tmpName= $_FILES['gambar']['tmp_name'];
	$size	= $_FILES['gambar']['size'];
	$type	= $_FILES['gambar']['type'];
	
	$maxsize= 1500000;
	$typeYgBoleh= array("image/jpeg","image/png","image/pjpeg");
	
	$dirFoto	= "pict";
	if (!is_dir($dirFoto))
		mkdir($dirFoto);
	$fileTujuanFoto= $dirFoto."/".$foto;
	
	$dirThumb	= "thumb";
	if (!is_dir($dirThumb))
		mkdir($dirThumb);
	$fileTuhuanThumb = $dirThumb."/t_".$foto;
	
	$dataValid="YA";
	
	if ($size > 0){
		if ($size > $maxsize){
			echo "Ukuran File Terlalu Besar <br/>";
			$dataValid="TIDAK";
		}
		if (!in_array($type, $typeYgBoleh)){
			echo "Tipe File Tidak Dikenal</br>";
			$dataValid="TIDAK";
		}
	}

	if (strlen(trim($kode))==0){
	echo "Kode Barang Harus diisi <br/>";
	$dataValid="TIDAK";
	}
	if (strlen(trim($merk))==0){
	echo "Merk Barang Harus diisi <br/>";
	$dataValid="TIDAK";
	}
	if (strlen(trim($jenis))==0){
	echo "Jenis Barang Belum dipilih <br/>";
	$dataValid="TIDAK";
	}
	if (strlen(trim($size))==0){
	echo "Ukuran Barang Belum Ditentukan <br/>";
	$dataValid="TIDAK";
	}
	if (strlen(trim($harga))==0){
	echo "Harga Harus diisi <br/>";
	$dataValid="TIDAK";
	}
	if (strlen(trim($stok))==0){
	echo "Stok Harus diisi <br/>";
	$dataValid="TIDAK";
	}
	if ($dataValid=="TIDAK"){
		echo "Masih Ada Kesalahan, silahkan perbaiki !<br/>";
		echo "<input type='button' value='KEMBALI'
		onClick='self.history.back()'>";
	}
	include "konektor.php";	
	$sql_produk ="insert into produk
			values
			('$kode','$merk' ,'$jenis', '$ukuran',$harga,$stok, '$foto')";
			
	$hasil = mysqli_query($akses, $sql_produk);
	
	if (!$hasil){
		echo "Gagal Simpan, silahkan ulangi kembali </br>";
		echo "</br><input type='button' value='KEMBALI' onClick='self.history.back()'>";
	}
	else {
		echo"<input type='button' value='KEMBALI' onClick='self.history.back()'></br></br>";
		echo "Simpan Data Berhasil";

	}
	if ($size>0){
		if (!move_uploaded_file($tmpName, $fileTujuanFoto)){
			echo "Gagal Upload Gambar..</br>";
			echo "<a href='barang_tampil.php'>Daftar Barang</a>";
			exit; }
		else {
			buat_thumbnail ($fileTujuanFoto, $fileTuhuanThumb);
		}
	}
	echo "<br/> File Sudah DiUpload.<br/>";
	function buat_thumbnail ($file_src, $file_dst){
		list($w_src, $h_src, $type)= getImageSize($file_src);
		
		switch ($type){
			case 1:
				$img_src=imagecreatefromgif($file_src);
				break;
			case 2:
				$img_src=imagecreatefromjpeg($file_src);
				break;
			case 3:
				$img_src=imagecreatefrompng($file_src);
				break;
		}
		$thumb = 100;
		if ($w_src > $h_src){
			$w_dst = $thumb;
			$h_dst=round($thumb / $w_src * $h_src);
		}
		else {
			$w_dst=round($thumb / $h_src * $w_src);
			$h_dst = $thumb;
		}
		$img_dst = imagecreatetruecolor($w_dst,$h_dst);//resample
		
		imagecopyresampled ($img_dst, $img_src, 0,0,0,0, $w_dst, $h_dst, $w_src, $h_src);
		imagejpeg($img_dst, $file_dst);
		imagedestroy ($img_src);
		imagedestroy ($img_dst);	
	}
include"bawah.php";
?>