<?php
include"atas.php";
	$no_telpon=$_POST['no_telpon'];
	echo "<h1>Transaksi Oleh :".$no_telpon."</h1></br>";
	echo "<input type='button' value='KEMBALI' onClick='self.history.back()'>";
	include"konektor.php";
	$sql="select * from transaksi where no_telpon='$no_telpon'";
	$hasil	= mysqli_query($akses,$sql);
						echo"<table border='1'>
					<tr>
					<th>NO</th>
					<th>NO_TELPON</th>
					<th>KODE BARANG</th>
					<th>TRANSAKSI</th>
					<th>BUKTI PEMBAYARAN</th>
					<th>TANGGAL PENGIRIMAN</th>
					</tr>";
			$no=0;
			while ($row=mysqli_fetch_assoc($hasil)) {
			$no++;
			echo "<tr>";
				echo "<td>".$no."</td>";
				
				echo "<td>".$row['no_telpon']."</td>";
				echo "<td>".$row['kode']."</td>";
				echo "<td>";
					echo $row['tglTransaksi']."</br>";
					echo $row['jumlah']."</br>";
					echo "Rp.".$row['totalPembayaran']."</br>";
					echo $row['status']."</br>";
				echo "</td>";
				echo "<td>";
				if (strlen (trim($row['buktiPembayaran']))>0) {
					echo "<a href ='buktiTransfer/{$row['buktiPembayaran']}'/>
				  <img src='thumb_buktiTransfer/t_{$row['buktiPembayaran']} ' width='100'/>
				  </a>";
				}
				else{
				echo"BELUM DIBAYAR";
				}
				echo "</td>";
				echo "<td>";
				if (strlen (trim($row['tglPengiriman']))>0) {
					echo $row['tglPengiriman'];
				}
				else{
				echo"<a href='kirimProduk.php?noTransaksi={$row['noTransaksi']}'>BARANG DIKIRIM HARI INI </a>";
				 }
				echo "</td>";
			}
			echo"</table>";
include"bawah.php";
?>