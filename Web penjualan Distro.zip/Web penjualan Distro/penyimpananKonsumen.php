<?php
	$noHP	= $_POST ['hp'];
	$nama	= $_POST ['nama'];
	$seks	= $_POST ['seks'];
	$alamat	= $_POST ['alamat'];
	$post	= $_POST ['post'];

	$dataValid="YA";
	if (strlen(trim($noHP))==0){
	echo "No Telpon belum diisi  <br/>";
	$dataValid="TIDAK";
	}
	if (strlen(trim($nama))==0){
	echo "Nama belum diisi <br/>";
	$dataValid="TIDAK";
	}
	if (strlen(trim($seks))==0){
	echo "Jenis Kelamin belum diisi  <br/>";
	$dataValid="TIDAK";
	}
	if (strlen(trim($alamat))==0){
	echo "Alamat belum diisi  <br/>";
	$dataValid="TIDAK";
	}
	if (strlen(trim($post))==0){
	echo "Kode Post belum diisi  <br/>";
	$dataValid="TIDAK";
	}
	if ($dataValid=="TIDAK"){
		echo "Masih Ada Kesalahan, silahkan perbaiki !<br/>";
		echo "<input type='button' value='KEMBALI'
		onClick='self.history.back()'>";
	}
	include "konektor.php";	
	$insert ="insert into konsumen
			values
			('$noHP','$nama' , '$seks','$alamat','$post')";
			
	$hasil = mysqli_query($akses, $insert);
header ('location:form_transaksi.php');
?>