<?php
$kode	=$_POST['kode'];
$harga	=$_POST['harga'];
$stok	=$_POST['stok'];
include "konektor.php";	

	$ambil = "select * from produk where kode='$kode'";
	
	$hasilambil = mysqli_query($akses, $edit);
	$row = mysqli_fetch_assoc($hasilambil);
	$stokbaru=$stok+$row['stok'];
	
			$edit = "update produk set 
					harga = '$harga',
					stok = '$stokbaru'
				where kode = '$kode'";
			
	$hasil = mysqli_query($akses, $edit);

include"atas.php";	
	if (!$hasil){
		echo "Perubahan Tidak dapat dilakukan, ulangi kembali </br>";
		echo "</br><input type='button' value='KEMBALI' onClick='self.history.back()'>";
	}
	else{
	echo"Pengubahan Berhasil";
	echo "</br><input type='button' value='KEMBALI' onClick='self.history.back()'>";
	}
include"bawah.php";
?>