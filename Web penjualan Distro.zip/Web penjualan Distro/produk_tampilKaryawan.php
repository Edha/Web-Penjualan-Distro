<?php
include"atas.php";
?>
<?php
	include"konektor.php";
	$sql 	= "select * from produk order by kode desc";
	$hasil	= mysqli_query($akses, $sql);
	if (!$hasil) die ("Gagal query..".mysqli_error($akses));
?>
<input type='button' value='KEMBALI' onClick='self.history.back()'></br></br>
<table border="1">
	<tr>
		<th>GAMBAR</th>
		<th>KODE</th>
		<th>MERK</th>
		<th>JENIS</th>
		<th>UKURAN</th>
		<th>HARGA</th>
		<th>STOK</th>
		<th>EDIT</th>
		
	</tr>
	<?php
	$no=0;
	while ($row = mysqli_fetch_assoc($hasil)){
		echo"<tr>";
			echo" <td> <a href='pict/{$row['foto']}'/>
				<img src='thumb/t_{$row['foto']}' width='70'/>
				</a> </td> ";
			echo"<td>".$row['kode']."</td>";
			echo"<td>".$row['merk']."</td>";
			echo"<td>".$row['jenis']."</td>";
			echo"<td>".$row['ukuran']."</td>";
			echo"<td>".$row['harga']."</td>";
			echo"<td>".$row['stok']."</td>";
			echo "<td>";
			echo "<a href='produk_formEdit.php?kode={$row['kode']}'>Edit</a> | ";
			echo "<a href='produk_hapus.php?kode={$row['kode']}'
				onClick='return confirm(\"Yakin AKan Menghapus \\n {$row['kode']} ?\")'>Hapus</a> ";
			echo "</td>";
		echo"</tr>";
	}
	?>
</table>
<?php
include"bawah.php";
?>