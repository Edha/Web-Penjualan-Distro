<?php
$no_telpon=$_POST['no_telpon'];
include"konektor.php";
	$sql = "select * from konsumen
		where no_telpon='$no_telpon'";
	$hsl	= mysqli_query($akses,$sql);
	$row = mysqli_fetch_assoc($hsl);
	$jumlah = mysqli_num_rows($hsl);
		if($jumlah<1){
			include"atas.php";
			echo"<form action='penyimpananKonsumen.php' method='post'>";
			echo"<h2>DATA DIRI KOSMEN</h2></br>";
			echo"<h4>Anda Harus melengkapi data diri anda terlebih dahulu</h4>";
				echo"<table>
						<tr>
							<td>No_HP</td>
							<td>:</td>
							<td><input type='text' name='hp'></td>
						</tr>
						<tr>
							<td>NAMA</td>
							<td>:</td>
							<td><input type='text' name='nama'></td>
						</tr>
						<tr>
							<td>KELAMIN</td>
							<td>:</td>
							<td>
							<input type='radio' name='seks' value='P' >PRIA
							<input type='radio' name='seks' value='W' >WANITA
							</td>
						</tr>
						<tr>
							<td>ALAMAT
							<td>:</td>
							<td><textarea name='alamat'></textarea>
							</td>
						</tr>
						<tr>
							<td>KODE POST</td> 
							<td>:</td>
							<td><input type='text' name='post'></td>
						</tr>
							<td colspan='2' align='center'>
								<input type='submit' value='SIMPAN'/>
								<input type='reset' value='BATAL'/>
							</td>
						</tr>
					</table>
			<form>";
			include"bawah.php";	
			exit;
		}
		else{
			include"atas.php";
			include"konektor.php";
			$sql 	= "select * from produk order by kode desc";
			$hasil	= mysqli_query($akses, $sql);
			echo "<table>";
			$no=0;
				echo"<tr>";
				while ($row = mysqli_fetch_assoc($hasil)){
					$no++;
					echo"<td>";
					echo" <a href='pict/{$row['foto']}'/>
						<img src='thumb/t_{$row['foto']}' width='147' height='150'/>
						</a></br>";
					echo $row['kode'];
					echo " | <a href='produk_datatunggal.php?kode={$row['kode']}'>CHEK</a>";
					echo"</td>";
						if ($no % 5==0){
							echo"<tr>";
						}
				}
				echo"<tr>";
				echo"</table>";
				include"bawah.php";
		}
?>