<?php
include"atas.php";
?>
<?php
	include"konektor.php";
	$sql 	= "select * from produk order by kode desc";
	$hasil	= mysqli_query($akses, $sql);
?>

<table>

	<?php
	$no=0;
	echo"<tr>";
	
	while ($row = mysqli_fetch_assoc($hasil)){
	$no++;
	if($row['stok']>=1){
			echo"<td>";
			echo" <a href='pict/{$row['foto']}'/>
				<img src='thumb/t_{$row['foto']}' width='147' height='150'/>
				</a></br>";
				echo $row['kode'];
			echo"</td>";
		if ($no % 5==0){
		echo"<tr>";
		}
	}	
	}
	
	echo"<tr>"
	?>
	

</table>
<?php
include"bawah.php";
?>