<?php
include"atas.php";
?>
<form action="produk_form.php" method="post">
<table width="405" height="169" border="0" cellpadding="0" cellspacing="0">

    <tr bgcolor="red">
      <td height="37" colspan="2"><div align="center" color="black"><strong>LOGIN KARYAWAN</strong></div></td>
    </tr>
    <tr>
      <td width="95" height="32">Username</td>
      <td width="304"><label>:
          <input type="text" name="name"/>
      </label></td>
    </tr>
    <tr>
      <td height="26">Password</td>
      <td><label>:
          <input type="password" name="pass"/>
      </label></td>
    </tr>
    <tr>
      <td height="48"> </td>
      <td><input type="submit" name="LOGIN" value="LOGIN" />
          <input type="reset" name="BATAL" value="BATAL" /></td>
    </tr>
    <tr bgcolor="red">
      <td height="26" colspan="2"><div align="center"><strong>DANGER OL SHOP</strong></div></td>
    </tr>
  </table>
 </form>
 <?php
include"bawah.php";
?>