	 </div>
	<div id="footer">
	<p style="font:11px Verdana">
		Hak Cipta &copy; 2015 Provinsi Daerah Istimewa Yogyakarta
		</p>
		<p style="font:11px Courier New">
		WEB INI DIBUAT OLEH</br>
TIOTIMUS (145610095)</br>
SUWEDA RAHMAN PRASETYO (145610154)

		</p>
		</div>	
</div>
</body>
</html>