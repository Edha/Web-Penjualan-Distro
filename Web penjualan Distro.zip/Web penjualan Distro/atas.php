<!DOCTYPE html>
<html>
<head>
<title>DANGER OL SHOP</title>
	<link rel="stylesheet" href="file.css" />
	<style type="text/css">
#wrap {
	max-width:1000px;
	margin:auto;
	background-color:lightyellow;
}
#menu_horizontal {
	width:1000px;
	height:30px;
	border:1px solid black;
	background-color:yellow;
	color:black;
	text-align:center;
	position:fixed;
	top:0px;
	z-index:200;
	box-shadow:5px 5px 5px gray;
	border-radius:10px;
}
#header {
	position:relative;
	top:27px;
	max-width:1000px;
	height:200px;
	background-image:url(gambar/danger4.jpg);
	display:block;
}
#slogan {
	position:absolute;
	width:400px;
	height:170px;
	top:10px;
	left:10px;
}
#gambar {
	position:absolute;
	width:400px;
	height:170px;
	top:10px;
	right:10px;

}
#kiri {
	width:200px;
	margin-top:30px;
	min-height:510px;
	position:relative;
	display:block;
	float:left;
}
#menu_vertikal {
	position:absolute;
	width:200px;
	height:300px;
	display:block;
	border:1px solid black;
	background-color:gray;
	color:white;
	line-height:30px;
	text-align:center;
}
#banner {
	position:absolute;
	top:330px;
	width:200px;
	min-height:175px;
	background-color:lime;
	display:block;
	border:1px solid black;
	margin-bottom:200px;
}
#content {
	float:center;
	width:775px;
	margin-top:30px;
	margin-left:5px;
	height:505px;
	background-color: yellow;
	display:block;
	border:1px solid black;
	color:black;
	overflow:scroll;
	text-align:left;
}
#footer {
	clear:both;
	margin-top:50px;
	max-width:1000px;
	height:80px;
	background-color:lightgray;
	color:black;
	display:block;
	text-align:center;
	padding:2px;
	opacity: 0.4;
	filter: alpha(opacity=40);
}
body {
	background-image:url(gambar/danger3.jpg)
}
#slogan h1 {
	font-family:gabriola;
	font-size:55px;
	text-align:center;
	font-weight:bold;
	color:red;
	margin-top:10px;
	margin-bottom:0px;
	padding:0;
	text-shadow:3px 2px 1px grey;

}
@font-face {
	font-family:gabrielle;
	src:url(gabrielle.ttf);
}
#slogan .slogan {
	font-family:tahoma,verdana,arial;
	font-size:14px;
	text-align:right;
	text-decoration:overline;
	color:yellow;
	font-weight:bold;
	font-style:italic;
}
#menu_vertikal li {
	list-style-type:none;
	text-align:left;
}
#menu_vertikal li a {
	text-decoration:none;
	width:175px;
	background-color:lightyellow;
	display:block;
	border-top:1px solid black;
	padding:.2em .8em;
}
#menu_vertikal ul {
	padding:0px;
	margin-top:8px;
}
#menu_vertikal li a:hover {
	background-color:lightgray;
	color:black;
}
#menu_horizontal ul{
	padding:0px;
	margin:3px;
	list-style-type:none;
	text-align:center;
}
#menu_horizontal li {
	display:inline;
}
#menu_horizontal li a {
	text-decoration:none;
	background-color:yellow;
	color:black;
	border-right:1px solid gray;
	padding: .2em 1em;
	font-size:12px;
}
#menu_horizontal li a:hover {
	background-color:yellow;
	color:white;
}
</style>
</head>
<body>
	<div id="wrap">
	<div id="menu_horizontal">Selamat Datang di DANGER OL SHOP</div>
	<div id="header">
		<div id="slogan">
			<h1>DANGER OL SHOP</h1>
			<div class ="slogan">Melayani Pembelian Segala Jenis Jersey</div>
		</div>
	</div>
	<div id="kiri">
		<div id="menu_vertikal">
		.:: Menu ::.
		<ul>
			<li><a href="home.php">HOME</a></li>
			<li><a href="produk_tampil.php" target=blank">PRODUK</a></li>
			<li><a href="form_transaksi.php" target=blank">PEMBELIAN BARANG</a></li>
			<li><a href="form_status.php" target=blank">STATUS PENGIRIMAN</a></li>
			<li><a href="login.php" target=blank">LOGIN KARYAWAN</a></li>
			<li><a href="aturan.php" target=blank">ATURAN PEMBELIAN</a></li>
			<li>
		</ul>
		</div>
		
		<div id="banner">
			<img src="gambar/danger2.jpg" width="200px" height="175px"/>
		</div>
	</div>
	<div id="content">
