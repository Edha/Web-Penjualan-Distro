<?php
error_reporting(E_ALL ^ E_DEPRECATED);
	$host= "localhost";
	$user= "a7029298";
	$pass= "Ab4444ng";
	$dataBase="a7029298_danger";
	
	$akses = mysqli_connect ($host, $user, $pass);
	if (!$akses)
		die("gagal Koneksi...");
		
	$hasil = mysqli_select_db($akses, $dataBase);
?>