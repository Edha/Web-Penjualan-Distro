<?php
include"atas.php";
?>
<h2>Selamat data di DANGER OL SHOP </br>
berikut fungsi dari menu-menu yang ada disamping</h2>
<table border="1">
	<tr>
		<th>MENU</th><th>KEGUNAAN</th>
	</tr>
	<tr>
		<td>PRODUK </td><td>digunakan jika anda hanya ingin melihat Produk yang ditawarkan</td>
	</tr>
	<tr>
		<td>PEMBELIAN BARANG </td><td>digunakan jika anda hendak membeli barang</td>
	</tr>
	<tr>
		<td>STATUS PENGIRIMAN </td><td>digunakan untuk melihat apakah </br>barang yang telah anda beli telah dikirim atau belum</td>
	</tr>
	<tr>
		<td>ATURAN PEMBELIAN </td><td>Petunjuk cara melakukan transaksi didalam DANGER OL SHOP</td>
	</tr>
</table>

<?php
include"bawah.php";
?>