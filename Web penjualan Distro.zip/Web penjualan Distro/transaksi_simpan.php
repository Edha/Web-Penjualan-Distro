<?php
$no_telpon=$_POST['no_telpon'];
$kode=$_POST['kode'];
$jumlah=$_POST['jumlah'];
$date=date("Y-m-d");
include "konektor.php";	

	$sqlStok ="select * from produk
				where kode='$kode'";
				
	$hasil	= mysqli_query($akses, $sqlStok);
	$row = mysqli_fetch_assoc($hasil);
	
	$harga=$row['harga'];

	$totalPembayaran = $jumlah*$harga;
	$insertBarang ="insert into transaksi (no_telpon,kode,tglTransaksi,jumlah, status, totalPembayaran)
			values
			('$no_telpon','$kode','$date',$jumlah,'MENUNGGU',$totalPembayaran)";
			
	$hasil = mysqli_query($akses, $insertBarang);
?>
<script>
	document.location.href="form_transaksi.php";
</script>