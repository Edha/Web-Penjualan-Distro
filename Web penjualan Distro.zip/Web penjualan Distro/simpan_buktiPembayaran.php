<?php
include"atas.php";
	$noTransaksi	= $_POST ['noTransaksi'];
	
	$foto	= $_FILES['gambar']['name'];
	$tmpName= $_FILES['gambar']['tmp_name'];
	$size	= $_FILES['gambar']['size'];
	$type	= $_FILES['gambar']['type'];
	
	$maxsize= 1500000;
	$typeYgBoleh= array("image/jpeg","image/png","image/pjpeg");
	
	$dirFoto	= "buktiTransfer";
	if (!is_dir($dirFoto))
		mkdir($dirFoto);
	$fileTujuanFoto= $dirFoto."/".$foto;
	
	$dirThumb	= "thumb_buktiTransfer";
	if (!is_dir($dirThumb))
		mkdir($dirThumb);
	$fileTujuanThumb = $dirThumb."/t_".$foto;
	
	$dataValid="YA";
	
	if ($size > 0){
		if ($size > $maxsize){
			echo "Ukuran File Terlalu Besar <br/>";
			$dataValid="TIDAK";
		}
		if (!in_array($type, $typeYgBoleh)){
			echo "Tipe File Tidak Dikenal</br>";
			$dataValid="TIDAK";
		}
	}
	if ($dataValid=="TIDAK"){
		echo "Masih Ada Kesalahan, silahkan perbaiki !<br/>";
		echo "<input type='button' value='KEMBALI'
		onClick='self.history.back()'>";
	}
	include "konektor.php";	
	$sql ="update transaksi
				set buktiPembayaran='$foto'
				where noTransaksi='$noTransaksi'";		
	$hasil = mysqli_query($akses, $sql);

	if ($size>0){
		if (!move_uploaded_file($tmpName, $fileTujuanFoto)){
			echo "Gagal Upload Gambar..</br>";
			echo "<a href='barang_tampil.php'>Daftar Barang</a>";
			exit; }
		else {
			buat_thumbnail ($fileTujuanFoto, $fileTujuanThumb);
		}
	}
	echo "<br/> File Sudah DiUpload.<br/>";
	function buat_thumbnail ($file_src, $file_dst){
		list($w_src, $h_src, $type)= getImageSize($file_src);
		
		switch ($type){
			case 1:
				$img_src=imagecreatefromgif($file_src);
				break;
			case 2:
				$img_src=imagecreatefromjpeg($file_src);
				break;
			case 3:
				$img_src=imagecreatefrompng($file_src);
				break;
		}
		$thumb = 100;
		if ($w_src > $h_src){
			$w_dst = $thumb;
			$h_dst=round($thumb / $w_src * $h_src);
		}
		else {
			$w_dst=round($thumb / $h_src * $w_src);
			$h_dst = $thumb;
		}
		$img_dst = imagecreatetruecolor($w_dst,$h_dst);//resample
		
		imagecopyresampled ($img_dst, $img_src, 0,0,0,0, $w_dst, $h_dst, $w_src, $h_src);
		imagejpeg($img_dst, $file_dst);
		imagedestroy ($img_src);
		imagedestroy ($img_dst);	
	}
	header ('location:form_status.php');
include"bawah.php";
?>