<?php
include"atas.php";
?>
<form action="status_pengiriman.php" method="post">
<h1>LOGIN PEMBELI</h1>
masukan nomor hp anda untuk mengetahui produk yang anda beli</br>
<h4>No_Telpon:<input type="text" name="no_telpon"/></h4>
<input type="submit" value="TAMPILKAN"/>
<form>
<?php
include"bawah.php";
?>