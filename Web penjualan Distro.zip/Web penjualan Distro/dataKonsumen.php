<?php
	include"konektor.php";
	$sql 	= "select * from konsumen order by no_telpon desc";
	$hasil	= mysqli_query($akses, $sql);
	if (!$hasil) die ("Gagal query..".mysqli_error($akses));
?>
<?php
include"atas.php";
?>
<input type='button' value='KEMBALI' onClick='self.history.back()'>
<table border="1" width="500">
	<tr>
		<th>NO</th>
		<th>No_TELPON</th>
		<th>NAMA</th>
		<th>JeKel</th>
		<th>ALAMAT</th>
		<th>KODE POST</th>
	</tr>
	<?php
	$no=0;
	while ($row = mysqli_fetch_assoc($hasil)){
		echo"<tr>";
			$no++;
			echo "<td>$no</td>";
			echo"<td>".$row['no_telpon']."</td>";
			echo"<td>".$row['nama']."</td>";
			echo"<td>".$row['jekel']."</td>";
			echo"<td>".$row['alamat']."</td>";
			echo"<td>".$row['Kode_Poss']."</td>";
		echo"</tr>";
	}
	?>
</table>
<?php
include"bawah.php";
?>