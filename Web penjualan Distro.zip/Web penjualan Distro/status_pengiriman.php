<?php
include"atas.php";
$no_telpon=$_POST['no_telpon'];
include"konektor.php";
$sqlstatus	="select * from transaksi where no_telpon='$no_telpon'";
			$hslstatus	= mysqli_query($akses,$sqlstatus);
			$jumlahstatus = mysqli_num_rows($hslstatus);
	if ($jumlahstatus>=1){
		$sql="select transaksi.noTransaksi,tglTransaksi,jumlah,totalPembayaran,status,tglPengiriman,buktiPembayaran,
				produk.kode,merk,foto,
				konsumen.no_telpon,nama
				from transaksi,produk,konsumen
				where transaksi.no_telpon=konsumen.no_telpon and produk.kode=transaksi.kode
				and transaksi.no_telpon='$no_telpon'";
			$hasil	= mysqli_query($akses,$sql);
			echo"BARANG YANG TELAH ANDA BELI";
			echo"<table border='1'>
					<tr>
					<th>NO</th>
					<th>PRODUK</th>
					<th>TRANSAKSI</th>
					<th>BUKTI PEMBAYARAN</th>
					<th>TANGGAL KIRIM BARANG</th>
					</tr>";
			$no=0;
			while ($row=mysqli_fetch_assoc($hasil)) {
			$no++;
			echo "<tr>";
				echo "<td>".$no."</td>";
				
				echo "<td><a href ='pict/{$row['foto']}'/>
				  <img src='thumb/t_{$row['foto']} ' width='100'/>
				  </a></td>";
				echo "<td>";
					echo $row['tglTransaksi']."</br>";
					echo $row['jumlah']."</br>";
					echo "Rp.".$row['totalPembayaran']."</br>";
				echo "</td>";
				echo "<td>";
				if (strlen (trim($row['buktiPembayaran']))>0) {
					echo "<a href ='buktiTransfer/{$row['buktiPembayaran']}'/>
				  <img src='thumb_buktiTransfer/t_{$row['buktiPembayaran']} ' width='100'/>
				  </a>";
				}
				else{
				
				  
				  echo "NO transaksi: ".$row['noTransaksi']."</br></br>";
					echo"<form action='simpan_buktiPembayaran.php' method='post' enctype='multipart/form-data'>";
					echo"Masukan No_Transaksi diatas</br><input type='text' name='noTransaksi'></br>";
					echo"UPLOAD BUKTI PENTRANSFERAN</br><input type='file' name='gambar'></br>";
					echo"<input type='submit' value='SIMPAN'>";
				}
				echo "</td>";
				echo "<td>";
					echo $row['tglPengiriman']."</br>";
				echo "</td>";
			echo " </tr> ";
			}
	}
	else{
	echo"ANDA BELUM PERNAH MELAKUKAN PEMBELIAN BARANG </br>";
	echo"<a href='form_transaksi.php'>BELI BARANG</a>";
	include"bawah.php";
	}
	
?>
			