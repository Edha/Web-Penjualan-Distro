<?php
include"atas.php";
?>
<form action="transaksi.php" method="post">
<h1>UNTUK MEMBELI BARANG ANDA HARUS MASUKAN NOMOR TELPON</br>UNTUK MENGETAHUI APAKAN NOMOR ANDA TELAH TERDAFTAR DIDATABASE</h1>
</br>
<h4>No_Telpon:<input type="text" name="no_telpon"/></h4>
<input type="submit" value="TAMPILKAN"/>
<form>
<?php
include"bawah.php";
?>