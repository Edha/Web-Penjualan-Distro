<?php
include"atas.php";
?>
<h2>Berikut TATA CARA dalam melakukan TRANSAKSI di DANGER OL SHOP</h2></br>
<h4>CARA MEMBELI</h4>
		<ul>
			<li>pilih menu PEMBELIAN BARANG </li>
			<li>Masukan Nomor telpon dengan Benar, </br>
				jika nomor telpon anda belum terdaftar didalam data base maka anda akan dibawa </br>
				ke form pengisian data. ISILAH DATA dengan BENAR, jika nomor anda telah terdaftar maka anda akan lasung masuk pada tampilan produk yang dapat anda beli</li>
			<li>setelah nomor anda terdaftar maka masuk kembali dengan menggunakan</br>
				nomor telpon yang telah anda daftarkan</li>
			<li>setelah masuk kedalam tampilan Produk yang dapat anda beli klik tulisan "CHEK" dibawah gambar Produk</br>
				dan isilah form pembelian dengan benar sesuai informasi yang tertera dibawah gambar pembelian</li>
			<li>setelah anda meng-Klik tombol beli maka anda harus login lagi menggunakan nomor telpon yang telah anda daftarkan, untuk membeli kembali</li>
		</ul>
<h4>CARA PENTRANSFERAN PEMBAYARAN</h4>
		<ul>
			<li>pilih menu STATUS PENGIRIMAN </li>
			<li>Transfer biaya yang harus anda bayar sesuai dengan angka yang tertera pada kolom transaksi baris ke-3 </br>
				nomor rekening DANGER OL SHOP tertera di BAWAH dan MENU HOME</li>
			<li>fotokan SLIP pengiriman anda dan Upload foto terbut kolom bukti pembayaran, sebelum disimpan isikan form</br>
				NO_TRANSAKSI yang berada tepat diatasnya</li>
			<li>CATAT NO_TRANSAKSI anda sebelum meng-Upload bukti pengiriman untuk komplen jika terjadi keterlambatan</br>
				komplen dapat dilakukan dengan menghungi nomor telpon <b>0823-5328-9396</b></li>
			<li>setelah bukti pengiriman di Upload Petugas akan segera menampilkan tanggal pengiriman barang anda. </li>
		</ul>
<h1>NO.REK DANGER OL SHOP : 767-50-1000-11-65-38</h1></br>
<h1>TERIMAKASIH ATAS KUNCUNGAN ADA DI DANGER OL SHOP</h1>
<?php
include"bawah.php";
?>