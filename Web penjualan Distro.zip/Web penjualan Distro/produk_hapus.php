<?php
	$kode = $_GET["kode"];
	include 'konektor.php';
	$sql = "delete from produk where kode = '$kode'";
	$hasil = mysqli_query($akses, $sql);
?>
<script type="text/javascript">
	document.location.href='produk_tampilKaryawan.php';
</script>