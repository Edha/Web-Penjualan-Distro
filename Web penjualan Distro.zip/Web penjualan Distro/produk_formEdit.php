<?php
	$kode = $_GET['kode'];
	include 'konektor.php';
	$sql = "select * from produk where kode = '$kode'";
	$res = mysqli_query($akses, $sql);
	$row = mysqli_fetch_array($res,MYSQL_ASSOC);
	$kode		= $row['kode'];
	$harga		= $row['harga'];
	$stok		= $row['stok'];
	$foto		= $row['foto'];
?>
<?php
include"atas.php";
?>
<form action="produk_edit.php" method="post">
<table>
	<tr>
		<?php
		echo"<a href='pict/{$row['foto']}'/>
			<img src='thumb/t_{$row['foto']}' width='70'/>";?>
	</tr>
	 <tr>
	  <td>KODE</td>
	  <td> : <input type="text" name="kode" size="10" maxlength="10"
				value="<?php echo $kode; ?>"	readonly	></td>
	</tr>
	<tr>
	  <td>HARGA</td>
	  <td> : <input type="text" name="harga" value="<?php echo $harga; ?>"></td>
    </tr>
	<tr>
	  <td>STOK</td>
	  <td> : <input type="text" name="stok" value="<?php echo $stok; ?>"></td>
    </tr>
    <tr>
		<td colspan="2">
			<input type="submit" value="TAMBAH">
			<input type="reset" value="RESET">
			<input type="button" value="KEMBALI" onClick="self.history.back()">
		</td>
	</tr>		
</table>	
</form>
<?php
include"bawah.php";
?>