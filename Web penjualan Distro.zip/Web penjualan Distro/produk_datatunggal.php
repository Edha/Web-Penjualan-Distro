<!DOCTYPE html>
<html>
<style type="text/css">
#menu_kanan {
	position: absolute;
	width: 430px;
	height:300px;
	display: block;
	left: 700px;
	top: 240px;
	background-color: yellow;
	
}
</style>
	<div id="menu_kanan"><b><u>FORM PEMBELIAN</u></b>
		<form action="transaksi_simpan.php" method="post">
			<table text-align="left">
			<tr>
			<td>NO_Telpon</br>
			KODE</br>
			JUMLAH</td>
			<td>:<input type="text" name="no_telpon" size="12" maxlength="12"/></br>
			:<input type="text" name="kode" size="7" maxlength="10"/></br>
			:<input type="text" name="jumlah" size="4" maxlength="10"/></td>
			</tr>
			</table>
			<input type="submit" value="BELI"/>
			<input type="reset" value="BATAL"/>
			<input type='button' value='KEMBALI' onClick='self.history.back()'>
		</form>
		Setelah anda melakukan Pembelian silahkan masuk kebagian Transaksi dan melengkapi data diri jika ternyata nomor anda belum terdaftar.
		upload Gambar bukti anda melakukan transfer pembayaran ke nomor REK DANGER OL SHOP supaya pengiriman barang dapat dilakukan
	</div>
</html>		

<?php
include"atas.php";
?>
<table>
<?php
		
	$kode = $_GET['kode'];
	include"konektor.php";
	$sql 	= "select * from produk where kode='$kode'";
	$hasil	= mysqli_query($akses, $sql);
	$row = mysqli_fetch_assoc($hasil);
		echo"<tr>";
			echo" <a href='pict/{$row['foto']}'/>
			<img src='thumb/t_{$row['foto']}' width='300' height='300'/>
			</a>";
		echo"</tr>";
		echo"<tr>";
			echo"<td>";
				echo "KODE </br>";
				echo "MERK </br>";
				echo "JENIS </br>";
				echo "UKURAN </br>";
				echo "HARGA </br>";
			echo"</td>";
			echo"<td>";
				echo  "<td>:".$row['kode']."</br>";
				echo ":".$row['merk']."</br>";
				echo ":".$row['jenis']."</br>";
				echo ":".$row['ukuran']."</br>";
				echo ":".$row['harga']."</br>";
			echo"</td>";
		echo"</tr>";
?>
</table>